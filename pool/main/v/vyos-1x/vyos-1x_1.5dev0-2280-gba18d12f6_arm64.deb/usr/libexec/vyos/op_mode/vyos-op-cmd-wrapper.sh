#!/bin/vbash
shopt -s expand_aliases
source /etc/default/vyatta
source /etc/bash_completion.d/vyatta-op
_vyatta_op_init
_vyatta_op_run "$@"
